#include<stdio.h>
main(){
    while(1){
        int *a=(int *)malloc(1024);
    }
}