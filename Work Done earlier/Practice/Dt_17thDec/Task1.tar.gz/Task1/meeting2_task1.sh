#!/bin/bash
cp ~/install ~/Work
~/Work/install