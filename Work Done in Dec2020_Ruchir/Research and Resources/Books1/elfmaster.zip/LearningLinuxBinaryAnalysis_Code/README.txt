Chapter 1 : No code present
Chapter 2 : No code present
Chapter 3 : Code present
Chapter 4 : Code present
Chapter 5 : Code present
Chapter 6 : No code present
Chapter 7 : Code present
Chapter 8 : No code present
Chapter 9 : No code present


The prerequisites for this book are as follows: 

We will assume that you have a working knowledge of the Linux command line, comprehensive C programming skills, and a very basic grasp on the x86 assembly language (this is helpful but not necessary).